﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace News
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            routes.MapRoute(
                name: "ArticleDetail",
                url: "News/{categorySlug}/{id}",
                defaults: new { controller = "PublicNews", action = "Detail" },
                constraints: new { id = @"\d+" }
            );

            routes.MapRoute(
                name: "Search",
                url: "Search",
                defaults: new { controller = "PublicNews", action = "Search" }
            );

            routes.MapRoute(
                name: "CategoryFeed",
                url: "News/{categorySlug}",
                defaults: new { controller = "PublicNews", action = "Category" }
            );
            // Root portal landing site setup
            routes.MapRoute(
                name: "RootHome",
                url: "",
                defaults: new { controller = "PublicNews", action = "Index" }
            );
            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
