﻿using System;
using System.Text;
using System.Web.Mvc;

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true, AllowMultiple = false)]
public class HttpBasicAuthorizeAttribute : ActionFilterAttribute
{
    // Hardcoded credentials for your admin team
    private const string AdminUser = "admin";
    private const string AdminPass = "123";

    public override void OnActionExecuting(ActionExecutingContext filterContext)
    {
        var request = filterContext.HttpContext.Request;
        var response = filterContext.HttpContext.Response;

        // 1. Look for the standard Authorization header from the browser
        string authHeader = request.Headers["Authorization"];

        if (!string.IsNullOrEmpty(authHeader) && authHeader.StartsWith("Basic ", StringComparison.OrdinalIgnoreCase))
        {
            try
            {
                // 2. Decode the Base64 credentials sent by the browser
                string base64Credentials = authHeader.Substring(6).Trim();
                string credentials = Encoding.UTF8.GetString(Convert.FromBase64String(base64Credentials));

                // Format sent by browser is always "username:password"
                int colonIndex = credentials.IndexOf(':');
                if (colonIndex >= 0)
                {
                    string username = credentials.Substring(0, colonIndex);
                    string password = credentials.Substring(colonIndex + 1);

                    // 3. Verify against the hardcoded account strings
                    if (username == AdminUser && password == AdminPass)
                    {
                        base.OnActionExecuting(filterContext);
                        return; // Access Granted! Proceed to controller action.
                    }
                }
            }
            catch
            {
                // If decoding fails, fall through to challenge the browser again
            }
        }

        // 4. Access Denied / Not logged in: Challenge the browser to show the pop-up prompt
        response.HeaderEncoding = Encoding.UTF8;
        response.StatusCode = 401; // Unauthorized status code triggers the prompt
        response.StatusDescription = "Unauthorized";

        // This specific header instructs the browser to open its native login UI popup
        response.AppendHeader("WWW-Authenticate", "Basic realm=\"News Administration Console\"");

        // Prevent MVC from processing the controller logic further
        filterContext.Result = new EmptyResult();
    }
}
