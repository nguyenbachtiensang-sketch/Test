﻿using News.Models;
using PagedList;
using PagedList.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace News.Areas.Admin.Controllers
{
    [HttpBasicAuthorize]
    public class ArticlesController : Controller
    {
        private NewsEntities2 db = new NewsEntities2();

        // GET: Admin/Articles
        public ActionResult Index(string searchTerm, string currentFilter, int? page)
        {
            int pageSize = 2;
            int pageNumber = page ?? 1;
            var articles = db.Articles.Include(a => a.Category);
            if (searchTerm != null)
            {
                // Reset to page 1 because a new filter alters the total record layout count
                page = 1;
            }
            else
            {
                searchTerm = currentFilter;
            }
            ViewBag.CurrentFilter = searchTerm;
            if (!string.IsNullOrEmpty(searchTerm))
            {
                articles = articles.Where(a => a.Title.Contains(searchTerm) || a.BodyContent.Contains(searchTerm) || a.Category.Name.Contains(searchTerm));
                ViewBag.SearchTerm = searchTerm; // Preserve the search term in the view
            }
            var pagedArticles = articles.OrderByDescending(a => a.PublishedAt).ToPagedList(pageNumber, pageSize);
            return View(pagedArticles);
        }

        // GET: Admin/Articles/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Article article = db.Articles.Find(id);
            if (article == null)
            {
                return HttpNotFound();
            }
            return View(article);
        }

        // GET: Admin/Articles/Create
        public ActionResult Create()
        {
            ViewBag.CategoryId = new SelectList(db.Categories, "CategoryId", "Slug");
            return View();
        }

        // POST: Admin/Articles/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ArticleId,CategoryId,Title,BodyContent,ImageUrl,PublishedAt")] Article article, HttpPostedFileBase imageFile)
        {
            if (ModelState.IsValid)
            {
                // A. Establish baseline timestamp data definitions
                article.PublishedAt = DateTime.Now;
                article.ImageUrl = ""; // Placeholder default state

                // B. First Save: Commits row to SQL Server to cleanly generate the incremental Identity primary key ([article number])
                db.Articles.Add(article);
                db.SaveChanges();

                // C. Intercept if the admin team uploaded an actual image file binary asset
                if (imageFile != null && imageFile.ContentLength > 0)
                {
                    // Construct structural path directory target: /Content/Images/42/
                    string folderRelativePath = "~/Content/Images/" + article.ArticleId + "/";
                    string folderAbsolutePath = Server.MapPath(folderRelativePath);

                    // Verify disk directory existence, build cleanly if missing
                    if (!Directory.Exists(folderAbsolutePath))
                    {
                        Directory.CreateDirectory(folderAbsolutePath);
                    }

                    // Extract file suffix extension securely (.jpg, .png etc)
                    string fileExtension = Path.GetExtension(imageFile.FileName);
                    string fileName = "featured" + fileExtension; // e.g. featured.jpg
                    string completePhysicalPath = Path.Combine(folderAbsolutePath, fileName);

                    // Stream file upload down into the physical disk subsystem safely
                    imageFile.SaveAs(completePhysicalPath);

                    // D. Second Save: Map the local relative file path back as the final string data asset property reference
                    article.ImageUrl = Url.Content(folderRelativePath + fileName); // Returns /Content/Images/42/featured.jpg
                    db.Entry(article).State = EntityState.Modified;
                    db.SaveChanges();
                }

                return RedirectToAction("Index");
                //article.PublishedAt = System.DateTime.Now;
                //db.Articles.Add(article);
                //db.SaveChanges();
                //return RedirectToAction("Index");
            }

            ViewBag.CategoryId = new SelectList(db.Categories, "CategoryId", "Slug", article.CategoryId);
            return View(article);
        }

        // GET: Admin/Articles/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Article article = db.Articles.Find(id);
            if (article == null)
            {
                return HttpNotFound();
            }
            ViewBag.CategoryId = new SelectList(db.Categories, "CategoryId", "Slug", article.CategoryId);
            return View(article);
        }

        // POST: Admin/Articles/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ArticleId,CategoryId,Title,BodyContent,ImageUrl,PublishedAt")] Article article, HttpPostedFileBase imageFile)
        {
            if (ModelState.IsValid)
            {
                // Intercept fresh upload overrides on editing updates
                if (imageFile != null && imageFile.ContentLength > 0)
                {
                    string folderRelativePath = "~/Content/Images/" + article.ArticleId + "/";
                    string folderAbsolutePath = Server.MapPath(folderRelativePath);

                    if (!Directory.Exists(folderAbsolutePath))
                    {
                        Directory.CreateDirectory(folderAbsolutePath);
                    }

                    string fileExtension = Path.GetExtension(imageFile.FileName);
                    string fileName = "featured" + fileExtension;
                    string completePhysicalPath = Path.Combine(folderAbsolutePath, fileName);

                    imageFile.SaveAs(completePhysicalPath);

                    // Assign the new locally mapped address link path
                    article.ImageUrl = Url.Content(folderRelativePath + fileName);
                }

                db.Entry(article).State = EntityState.Modified;
                db.Entry(article).Property(x => x.PublishedAt).IsModified = false; // Protect original timestamp updates

                db.SaveChanges();
                return RedirectToAction("Index");
                //db.Entry(article).State = EntityState.Modified;
                //// CRUCIAL: Tell EF6 NOT to update the original timestamp field in the database
                //db.Entry(article).Property(x => x.PublishedAt).IsModified = false;
                //db.SaveChanges();
                //return RedirectToAction("Index");
            }
            ViewBag.CategoryId = new SelectList(db.Categories, "CategoryId", "Slug", article.CategoryId);
            return View(article);
        }

        // GET: Admin/Articles/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Article article = db.Articles.Find(id);
            if (article == null)
            {
                return HttpNotFound();
            }
            // Renders Delete.cshtml ("Are you sure you want to delete this?")
            return View(article);
        }

        // POST: Admin/Articles/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Article article = db.Articles.Find(id);
            if (article != null)
            {
                // Construct targeted storage space path
                string folderRelativePath = "~/Content/Images/" + id + "/";
                string folderAbsolutePath = Server.MapPath(folderRelativePath);

                // Instantly scrub files and directory structure clean out of existence
                if (Directory.Exists(folderAbsolutePath))
                {
                    Directory.Delete(folderAbsolutePath, true);
                }

                db.Articles.Remove(article);
                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
