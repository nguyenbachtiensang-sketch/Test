﻿using News.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using PagedList;
using PagedList.Mvc;

namespace News.Controllers
{
    public class PublicNewsController : Controller
    {
        private readonly NewsEntities2 db = new NewsEntities2();
        // GET: PublicNews
        //public ActionResult Index()
        //{
        //    return View();
        //}
        // GET: / (Home timeline aggregation across ALL categories)
        //public ActionResult FrontPage()
        //{
        //    var allArticles = db.Articles
        //        .Include(a => a.Category)
        //        .OrderByDescending(a => a.PublishedAt)
        //        .Take(15)
        //        .ToList();

        //    return View("FrontPage", allArticles);
        //}
        public ActionResult Index()
        {
            var allArticles = db.Articles
                .Include(a => a.Category)
                .OrderByDescending(a => a.PublishedAt)
                .Take(15)
                .ToList();

            return View("FrontPage", allArticles);
        }
        // GET: /news/category-slug
        public ActionResult Category(string categorySlug, int? page)
        {
            if (string.IsNullOrEmpty(categorySlug)) return HttpNotFound();

            // 1. Fetch the requested Category entity record
            var currentCategory = db.Categories.FirstOrDefault(c => c.Slug == categorySlug);
            if (currentCategory == null) return HttpNotFound();

            // 2. Set pagination limits (e.g., 6 articles per page for a beautiful timeline cadence)
            int pageSize = 2;
            int pageNumber = page ?? 1;

            // 3. Construct the timeline query stream (Deferred execution via EF6)
            var categoryArticles = db.Articles
                .Where(a => a.CategoryId == currentCategory.CategoryId)
                .OrderByDescending(a => a.PublishedAt);

            // 4. Force server-side paging execution
            var pagedArticles = categoryArticles.ToPagedList(pageNumber, pageSize);

            ViewBag.CategoryName = currentCategory.Name;
            ViewBag.CategorySlug = currentCategory.Slug;

            return View("CategoryPage", pagedArticles);
        }

        // GET: /Search?q=term
        public ActionResult Search(string q, int? page)
        {
            var searchTerm = (q ?? string.Empty).Trim();
            int pageSize = 2;
            int pageNumber = page ?? 1;

            var searchArticles = db.Articles
                .Include(a => a.Category)
                .OrderByDescending(a => a.PublishedAt)
                .AsQueryable();

            if (string.IsNullOrEmpty(searchTerm))
            {
                searchArticles = searchArticles.Where(a => false);
            }
            else
            {
                searchArticles = searchArticles.Where(a =>
                    a.Title.Contains(searchTerm) || a.BodyContent.Contains(searchTerm));
            }

            var pagedArticles = searchArticles.ToPagedList(pageNumber, pageSize);

            ViewBag.SearchQuery = searchTerm;

            return View("SearchPage", pagedArticles);
        }

        // GET: /news/category-slug/104
        public ActionResult Detail(string categorySlug, int id)
        {
            var article = db.Articles
                .Include(a => a.Category)
                .FirstOrDefault(a => a.ArticleId == id && a.Category.Slug == categorySlug);

            if (article == null) return HttpNotFound();

            return View("ArticlePage", article);
        }

        // Navigation Menu Injector Component
        [ChildActionOnly]
        public ActionResult CategoryMenu()
        {
            var categories = db.Categories.OrderBy(c => c.Name).ToList();
            return PartialView("_CategoryMenu", categories);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) db.Dispose();
            base.Dispose(disposing);
        }
    }
}