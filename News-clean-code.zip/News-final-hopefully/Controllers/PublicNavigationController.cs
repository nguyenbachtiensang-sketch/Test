﻿using News.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace News.Controllers
{
    public class PublicNavigationController : Controller
    {
        private readonly NewsEntities2 db = new NewsEntities2();

        [ChildActionOnly] // Completely blocks public entry endpoints via web browsers
        public ActionResult CategoryMenu()
        {
            // Pull the categories synchronously to build the top navigation links
            var categories = db.Categories.OrderBy(c => c.Name).ToList();
            return PartialView("_CategoryMenu", categories);
        }
        // GET: PublicNavigation
        //public ActionResult Index()
        //{
        //    return View();
        //}
    }
}